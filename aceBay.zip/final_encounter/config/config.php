<?php

   //$base_url="http://babastudio.org/php3/";
   $base_url="http://localhost/final_encounter/"; 
   
   $adminlayoutmodule_url="modules/";
	
   $display_image_url=$base_url . "images/" ;
?>