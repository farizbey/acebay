<?php
 /* $koneksi=mysql_connect("localhost","root","");
  mysql_select_db("fr_shoesstoredb",$koneksi);
  $data_perpage=5;*/
  
  $db_server="localhost";
  $db_user="root";
  $db_password="";
  $db_selected="farizbey_personalwebdb";
?>