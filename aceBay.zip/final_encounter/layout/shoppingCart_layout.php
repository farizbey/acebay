<?php 

?>

<!-- <div class="container"> -->
	<table id="cartx" class="table table-hover table-condensed">
    	<!-- ajax calling -->
	</table>
	<div class="pull-left">
	<a href="javascript:" id="clearcart" class="btn btn-danger"><i class="fa fa-times"></i> Clear All Product</a>
	</div>
	<div class="pull-right">
	<a href="index.php?checkOut" class="btn btn-success btn-block">Checkout <i class="fa fa-angle-right"></i></a>
	</div>
<!-- </div> -->
