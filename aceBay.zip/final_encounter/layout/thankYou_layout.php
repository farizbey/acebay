<?php 

?>

<meta http-equiv="refresh" content="3;url=index.php?home" />

<div class="text-center" style="margin: 300px; font-size: 2.5em;">Thank You</div>