<?php


?>
	<!-- Content Profile Start -->
	<section class="profile">
		<div class="col-md-12">
			<div class="row">
			  	<div class="col-xs-12 col-sm-12 col-md-4">
			   		<div class="thumbnail">
			      		<img src="images/uncharted.jpg" alt="...">
			      		<div class="caption">
			      			<p class="text-center">"I'm a Man of Fortune and I Must Seek My Fortune"</p>
			      		</div>
			    	</div>
			  	</div>

			  	<div class="col-xs-12 col-sm-12 col-md-8">
			  		<div class="thumbnail">
			      		<li>Name: Fariz Rakhman Bey</li>
			      		<li>Birthdate: 24 June 1984</li>
			      		<li>Gender:	Male</li>
			      		<li>Status: Single</li>
			      	</div>
			    </div>
			</div>

			<div class="col-md-12">
				<div class="well kolom">
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur tortor arcu, cursus sed dapibus sit amet, iaculis et sem. Ut fringilla dictum sagittis. Nullam libero nisl, volutpat sit amet bibendum a, suscipit in lorem. Sed tempus, urna vitae convallis sagittis, ligula velit faucibus felis, sit amet venenatis sapien erat sit amet mi. Mauris vitae arcu diam. Fusce rhoncus bibendum ligula sed fringilla. Aliquam metus magna, condimentum a lectus et, dignissim accumsan nunc.</p>
				</div>
			</div>	
		</div>
	</section>
	<!-- Content Profile Ends -->


<?php 



?>
